import 'package:flutter/material.dart';
import 'watermaniac_app.dart';

void main () {
  runApp(WatermaniacApp());
}